import React from 'react'
import { useSelector } from 'react-redux'
import './Payment.css'

const Payment = () => {
    const totalPrice = useSelector((state)=>state.cartReducer.price)
  return (
    <>
      <div className='mainBox flex'>
            <div className='leftSide'>
                <h2>Select Payment Method</h2>
                <p>All transactions are safe and secure</p>
                <hr/>
                <form>
                    <div className='flex contact'>
                    <input type="radio" className='radioBtn'/>
                        <h3 className=''>Credit/Debit Card</h3>
                    </div>



                    <input type="text" placeholder='Card Holder Name' />
                    <input type="number" placeholder='Phone number'/>

                    
                    <input type="number" placeholder='Card Number'/>
                    
                    
                    <div className='flex CSBox'>
                        <input className='city' type="date" placeholder='MM / YY'/>
                        <input className='state' type="password" placeholder='CVV'/>
                    </div>
                    

{/* -------- */}
                    <div className='flex contact'>
                    <input type="radio" className='radioBtn'/>
                        <h3 className=''>Cash on Delivery</h3>
                    </div>
                    
                    <button className='SaveBtn'>Place Order</button>
                   
                </form>
               
            </div>


{/* xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx */}
            <div className='rightSide'>
                <h3>Price Details</h3>
                <div className='flex'>
                    <p className='ltitle'>Total Product Price </p>
                    <p className='leftAmount'> $ {totalPrice}</p>
                </div>
                <div className='flex'>
                    <p className='green ltitle'>Meesho Discount </p>
                    <p className='leftAmount green'> -$ {}</p>
                </div>
<hr/>
                <div className='flex'>
                <h3 className='ltitle'>Order Total </h3>
                <p className='leftAmount'> $ {totalPrice}</p>
            </div>
            </div>



      </div>

    </>
  )
}

export default Payment









