import React from 'react'
import './SignUp.css'

const SignUp = () => {
  return (
    <>
     <div className='mainBox'>
          <div className='subBox1'>
              <h1>New Account</h1>
              <form action=""  className='form1'>
                <input type="text" placeholder='Full Name'/>
                <input type="email" placeholder='Email'/>
                <input type="password" placeholder='Password'/>
                <button className='btn1'>Sign up</button>
              </form>
          </div>
<hr/>
          <div className='subBox2'>
              <h1>Back to Account</h1>
              <form action="" className='form2'>
                <input className='none' type="text" />
                <input type="email" placeholder='Email'/>
                <input type="password" placeholder='Password'/>
                <button className='btn2'>Log in</button>
              </form>
          </div>
          
       
       
       
     </div> 
    </>
  )
}

export default SignUp
