import React from 'react'
import './Address.css'
import LocalPhoneIcon from '@mui/icons-material/LocalPhone';
import FmdGoodIcon from '@mui/icons-material/FmdGood';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';

const Address = () => {

    const totalPrice = useSelector((state)=>state.cartReducer.price)



  return (
    <>
      <div className='mainBox flex'>
            <div className='leftSide'>
                <h2>Select Delivery Address</h2>
                <form>
                    <div className='flex contact'>
                        <LocalPhoneIcon/>
                        <h3>Contact Details</h3>
                    </div>
                    <input type="text" placeholder='Name' />
                    <input type="number" placeholder='Phone number'/>

                    <div className='flex contact'>
                        <FmdGoodIcon/>
                        <h3>Address</h3>
                    </div>
                    <input type="text" placeholder='House no./ Building Name'/>
                    <input type="text" placeholder='Road Name/ Area/ Colony'/>
                    <input type="number" placeholder='Pincone'/>
                    <div className='flex CSBox'>
                        <input className='city' type="text" placeholder='City'/>
                        <input className='state' type="text" placeholder='State'/>
                    </div>
                    <input type="text" placeholder='Nearby Location (Optional)'/>

                    
                    <button className='SaveBtn'> <Link to='/product/payment' className='linkBtn'>Save Address & Continue</Link> </button>

                </form>

            </div>


{/* xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx */}
            <div className='rightSide'>
                <h3>Price Details</h3>
                <div className='flex'>
                    <p className='ltitle'>Total Product Price </p>
                    <p className='leftAmount'> $ {totalPrice}</p>
                </div>
                <div className='flex'>
                    <p className='green ltitle'>Meesho Discount </p>
                    <p className='leftAmount green'> -$ {}</p>
                </div>
<hr/>
                <div className='flex'>
                <h3 className='ltitle'>Order Total </h3>
                <p className='leftAmount'> $ {totalPrice}</p>
            </div>
            </div>



      </div>
    </>
  )
}

export default Address
