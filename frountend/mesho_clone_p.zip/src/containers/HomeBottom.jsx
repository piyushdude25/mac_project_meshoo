import React from 'react'
import './HomeBottom.css'

import FacebookIcon from '@mui/icons-material/Facebook';
import InstagramIcon from '@mui/icons-material/Instagram';
import LinkedInIcon from '@mui/icons-material/LinkedIn';
import YouTubeIcon from '@mui/icons-material/YouTube';
import TwitterIcon from '@mui/icons-material/Twitter';
import { Link } from "react-router-dom";
import "./SearchAppBar.css";



import Carousel from "react-elastic-carousel"
// import Item from './Item'

const breakPoint = [
  // {width:1,itemToShow:1},
  // {width:1000,itemToShow:2},
  // {width:768,itemToShow:3},
  // {width:1200,itemToShow:4},
]

const HomeBottom = () => {

  return (
    <div>
      <br/>
{/* ///////////////////dropdown start /////////// */}

<div className="flex DropDownBox">
        <div className="dropdown">
          <div className="dropbtn">Men Ethic</div>
          <div className="dropdown-content c1">
            <div className="row flex">
              <div className="column">
                <h3><Link to="product" className="productLink">Top Wear</Link>
                </h3>
                {/* <li><Link to ='product'>Product Page</Link></li> */}
                <ul>All Top Wear</ul>
                <ul>Tshirtsg</ul>
                <ul>Shirts</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">Bottom Wear </Link></h3>
                <ul>Track Pants</ul>
                <ul>Jeans</ul>
                <ul>Trousers</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">Men Accessories </Link></h3>
                <ul>Watches</ul>
                <ul>Belts</ul>
                <ul>Wallets</ul>
                <ul>Bags</ul>
                <ul>Sunglasses</ul>
              </div>
            </div>
          </div>
        </div>
        <div className="dropdown">
          <div className="dropbtn">Women Ethic</div>
          <div className="dropdown-content c2">
            <div className="row flex">
              <div className="column">
                <h3><Link to="product" className="productLink">FACE </Link></h3>
                <ul>Cleansers</ul>
                <ul>Exfoliating & Peeling</ul>
                <ul>Toners/ Face Mist</ul>
                <ul>Serum & Concentrates</ul>
                <ul>Moisturizers & Treatments</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">LIPS </Link></h3>
                <ul>Lipsticks</ul>
                <ul>Lip Balms & Tints</ul>
                <ul>Lip Gloss</ul>
                <ul>Lip Liner</ul>
                <ul>Lip Guide</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">EYES </Link></h3>
                <ul>Eyeliner/Kajal</ul>
                <ul>Mascara</ul>
                <ul>Eye Shadow</ul>
                <ul>Brows</ul>
                <ul>Eye Shadow Guide</ul>
              </div>
            </div>
          </div>
        </div>

        <div className="dropdown">
          <div className="dropbtn">Men Ethic</div>
          <div className="dropdown-content c3">
            <div className="row flex">
              <div className="column">
                <h3><Link to="product" className="productLink">Top Wear</Link> </h3>
                <ul>All Top Wear</ul>
                <ul>Tshirtsg</ul>
                <ul>Shirts</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">Bottom Wear </Link></h3>
                <ul>Track Pants</ul>
                <ul>Jeans</ul>
                <ul>Trousers</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">Men Accessories </Link></h3>
                <ul>Watches</ul>
                <ul>Belts</ul>
                <ul>Wallets</ul>
                <ul>Bags</ul>
                <ul>Sunglasses</ul>
              </div>
            </div>
          </div>
        </div>
        <div className="dropdown">
          <div className="dropbtn">Women Ethic</div>
          <div className="dropdown-content c4">
            <div className="row flex">
              <div className="column">
                <h3><Link to="product" className="productLink">FACE </Link></h3>
                <ul>Cleansers</ul>
                <ul>Exfoliating & Peeling</ul>
                <ul>Toners/ Face Mist</ul>
                <ul>Serum & Concentrates</ul>
                <ul>Moisturizers & Treatments</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">LIPS </Link></h3>
                <ul>Lipsticks</ul>
                <ul>Lip Balms & Tints</ul>
                <ul>Lip Gloss</ul>
                <ul>Lip Liner</ul>
                <ul>Lip Guide</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">EYES </Link></h3>
                <ul>Eyeliner/Kajal</ul>
                <ul>Mascara</ul>
                <ul>Eye Shadow</ul>
                <ul>Brows</ul>
                <ul>Eye Shadow Guide</ul>
              </div>
            </div>
          </div>
        </div>

        <div className="dropdown">
          <div className="dropbtn">Men Ethic</div>
          <div className="dropdown-content c5">
            <div className="row flex">
              <div className="column">
                <h3><Link to="product" className="productLink">Top Wear </Link></h3>
                <ul>All Top Wear</ul>
                <ul>Tshirtsg</ul>
                <ul>Shirts</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">Bottom Wear </Link></h3>
                <ul>Track Pants</ul>
                <ul>Jeans</ul>
                <ul>Trousers</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">Men Accessories </Link></h3>
                <ul>Watches</ul>
                <ul>Belts</ul>
                <ul>Wallets</ul>
                <ul>Bags</ul>
                <ul>Sunglasses</ul>
              </div>
            </div>
          </div>
        </div>
        <div className="dropdown">
          <div className="dropbtn">Women Ethic</div>
          <div className="dropdown-content c6">
            <div className="row flex">
              <div className="column">
                <h3><Link to="product" className="productLink">FACE </Link></h3>
                <ul>Cleansers</ul>
                <ul>Exfoliating & Peeling</ul>
                <ul>Toners/ Face Mist</ul>
                <ul>Serum & Concentrates</ul>
                <ul>Moisturizers & Treatments</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">LIPS </Link></h3>
                <ul>Lipsticks</ul>
                <ul>Lip Balms & Tints</ul>
                <ul>Lip Gloss</ul>
                <ul>Lip Liner</ul>
                <ul>Lip Guide</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">EYES </Link></h3>
                <ul>Eyeliner/Kajal</ul>
                <ul>Mascara</ul>
                <ul>Eye Shadow</ul>
                <ul>Brows</ul>
                <ul>Eye Shadow Guide</ul>
              </div>
            </div>
          </div>
        </div>

        <div className="dropdown">
          <div className="dropbtn">Men Ethic</div>
          <div className="dropdown-content c7">
            <div className="row flex">
              <div className="column">
                <h3><Link to="product" className="productLink">Top Wear </Link></h3>
                <ul>All Top Wear</ul>
                <ul>Tshirtsg</ul>
                <ul>Shirts</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">Bottom Wear </Link></h3>
                <ul>Track Pants</ul>
                <ul>Jeans</ul>
                <ul>Trousers</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">Men Accessories </Link></h3>
                <ul>Watches</ul>
                <ul>Belts</ul>
                <ul>Wallets</ul>
                <ul>Bags</ul>
                <ul>Sunglasses</ul>
              </div>
            </div>
          </div>
        </div>
        <div className="dropdown">
          <div className="dropbtn">Women Ethic</div>
          <div className="dropdown-content c8">
            <div className="row flex">
              <div className="column">
                <h3><Link to="product" className="productLink">FACE </Link></h3>
                <ul>Cleansers</ul>
                <ul>Exfoliating & Peeling</ul>
                <ul>Toners/ Face Mist</ul>
                <ul>Serum & Concentrates</ul>
                <ul>Moisturizers & Treatments</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">LIPS </Link></h3>
                <ul>Lipsticks</ul>
                <ul>Lip Balms & Tints</ul>
                <ul>Lip Gloss</ul>
                <ul>Lip Liner</ul>
                <ul>Lip Guide</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">EYES </Link></h3>
                <ul>Eyeliner/Kajal</ul>
                <ul>Mascara</ul>
                <ul>Eye Shadow</ul>
                <ul>Brows</ul>
                <ul>Eye Shadow Guide</ul>
              </div>
            </div>
          </div>
        </div>

        <div className="dropdown">
          <div className="dropbtn">Men Ethic</div>
          <div className="dropdown-content c9">
            <div className="row flex">
              <div className="column">
                <h3><Link to="product" className="productLink">Top Wear </Link></h3>
                <ul>All Top Wear</ul>
                <ul>Tshirtsg</ul>
                <ul>Shirts</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">Bottom Wear </Link></h3>
                <ul>Track Pants</ul>
                <ul>Jeans</ul>
                <ul>Trousers</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">Men Accessories </Link></h3>
                <ul>Watches</ul>
                <ul>Belts</ul>
                <ul>Wallets</ul>
                <ul>Bags</ul>
                <ul>Sunglasses</ul>
              </div>
            </div>
          </div>
        </div>

        <div className="dropdown">
          <div className="dropbtn">Women Ethic</div>
          <div className="dropdown-content c10">
            <div className="row flex">
              <div className="column">
                <h3><Link to="product" className="productLink">FACE </Link></h3>
                <ul>Cleansers</ul>
                <ul>Exfoliating & Peeling</ul>
                <ul>Toners/ Face Mist</ul>
                <ul>Serum & Concentrates</ul>
                <ul>Moisturizers & Treatments</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">LIPS </Link></h3>
                <ul>Lipsticks</ul>
                <ul>Lip Balms & Tints</ul>
                <ul>Lip Gloss</ul>
                <ul>Lip Liner</ul>
                <ul>Lip Guide</ul>
              </div>
              <div className="column">
                <h3><Link to="product" className="productLink">EYES </Link></h3>
                <ul>Eyeliner/Kajal</ul>
                <ul>Mascara</ul>
                <ul>Eye Shadow</ul>
                <ul>Brows</ul>
                <ul>Eye Shadow Guide</ul>
              </div>
            </div>
          </div>
        </div>
      </div>







      
{/* <<<<<<<<<<<<<<<   B Start     >>>>>>>>>>>>>>>>.>>>>></> */}
<div className='HomeBottom'>
  <br/>
          {/* ....................................... */}


          <div className='img3Div'>
            <h1>Top Categories to choose from</h1>
            <div className='flex img3'>
              <img src='https://images.meesho.com/images/marketing/1649760442043.webp' alt=''/>
              <img src='https://images.meesho.com/images/marketing/1649759799809.webp' alt=''/>
              <img src='https://images.meesho.com/images/marketing/1649760423313.webp' alt=''/>
              
            </div>
          </div>
       
{/* ,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,,...................... */}
<br/><br/><br/>


      <div className='scrolling_img_box'>
        <Carousel breakPoint={breakPoint}>
          <span><img className='scroling_img'  src='https://tse2.mm.bing.net/th?id=OIP.-NRNT00hq9n3QxDydjegkgHaEK&pid=Api&P=0&w=279&h=157' alt=''/></span>
          <span><img className='scroling_img' src='https://tse2.mm.bing.net/th?id=OIP._qP_6OyYK9LC-O3zfmHw9wHaEK&pid=Api&P=0&w=279&h=157' alt=''/></span>
          <span><img className='scroling_img' src='https://tse2.mm.bing.net/th?id=OIP.JyUXoDOi-aPEWq4UtYTcDgHaEK&pid=Api&P=0&w=317&h=178' alt=''/></span>
          <span><img className='scroling_img' src='https://tse1.mm.bing.net/th?id=OIP.f5aU5ug9CoSgqCnyzhB35QHaEK&pid=Api&P=0&w=283&h=159' alt=''/></span>
           
        </Carousel>
      </div>  

<div className='img1'>
    <img src='https://images.meesho.com/images/pow/download_banner_desktop.webp' alt=''/>
</div>

<br/><br/><br/>

<div className='img3Div'>
            <h1>Top Categories to choose from</h1>
            <div className='flex img3'>
             
              <img src='https://images.meesho.com/images/marketing/1649760423313.webp' alt=''/>
              <img src='https://images.meesho.com/images/marketing/1649760442043.webp' alt=''/>
              <img src='https://images.meesho.com/images/marketing/1649759799809.webp' alt=''/>
            </div>
          </div>
          <br/><br/><br/>
          <div className='img3Div'>
            <h1>Top Categories to choose from</h1>
            <div className='flex img3'>
            <img src='https://images.meesho.com/images/marketing/1649759799809.webp' alt=''/>
              <img src='https://images.meesho.com/images/marketing/1649760423313.webp' alt=''/>
              
              <img src='https://images.meesho.com/images/marketing/1649760442043.webp' alt=''/>
            </div>
          </div>
          <br/><br/><hr/><br/><br/>

<div className='flex x'>

    <div className='a'>
        <h1>Shop Non-Stop on Meesho</h1>
        <p>Trusted by more than 1 Crore Indians Cash on Delivery | Free Delivery</p>

    </div>
    <div className='b'>
        <p>Careers</p>
        <p>Become a supplier</p>
        <p>Our Influencer Program</p>
        <p>Hall of Fame</p>
        
    </div>
    <div className='c'>
        <p>Legal and Policies</p>
        <p>Meesho Tech Blog</p>
        <p>Notices and Returns</p>
        <p>Hall of Fame</p>
        
    </div>
    <div className='d'>
        <h3>Reach out to us</h3>
        <FacebookIcon/>
        <InstagramIcon/>
        <LinkedInIcon/>
        <YouTubeIcon/>
        <TwitterIcon/>
        
    </div>
    <div className='e'>
        <h3>Contact Us</h3>
        <p>Fashnear Technologies Private Limited,
CIN: U74900KA2015PTC082263
06-105-B, 06-102, (138 Wu) Vaishnavi Signature, No. 78/9, Outer Ring Road, Bellandur, Varthur Hobli, Bengaluru-560103, Karnataka, India
E-mail address: query@meesho.com
© 2015-2022 Meesho.comr</p>
        
        
    </div>

</div>

{/* ................................................................ */}
</div>
{/* <<<<<<<<<<<<<<<  B End    >>>>>>>>>>>>>>>>.>>>>></> */}
    </div>
  )
}

export default HomeBottom
