import React from 'react'
import SearchAppBar from './SearchAppBar'
import HomeBottom from './HomeBottom'


const Header = () => {
  return (
    <div>
        


        <div>
      <SearchAppBar/>
        </div>

      


    </div>
  )
}

export default Header
