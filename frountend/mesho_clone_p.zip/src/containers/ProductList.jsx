import React, { useEffect } from "react";
import axios from "axios";
import { useDispatch, useSelector } from "react-redux";
import { setProducts } from "../redux/actions/ProductAction";
import ProductComponent from "./ProductComponent";
import "./ProductList.css";
import { useState } from "react";

import Backdrop from '@mui/material/Backdrop';
import CircularProgress from '@mui/material/CircularProgress';


const ProductPage = () => {
  const products = useSelector((state) => state.allProducts.products);
  const dispatch = useDispatch();
  const [price, setPrice] = useState("price");
  const [order, setOrder] = useState();

  const fetchProducts = async () => {
    const response = await axios
    .get(" http://localhost:8081/products")
   
      // .get("https://fakestoreapi.com/products")
      
      // .get("https://meesho123.herokuapp.com/products", {
      //   params: {
      //     _sort: price,
      //     _order: order,
      //   },
      // })

      .catch((err) => {
        console.log("Err: ", err);
      });
    // console.log("res:",response.data);
    dispatch(setProducts(response.data));
  };

  useEffect(() => {
    fetchProducts();
  }, [order]);

  console.log("Products :", products);
  return (
    <>
      <div className="sortBtns">
        {" "}
        <button
          onClick={() => {
            setOrder("asc");
          }}
        >
          low to high
        </button>
        <button
          onClick={() => {
            setOrder("desc");
          }}
        >
          high to low
        </button>

  

      </div>


      {products.length === 0 ? ( <Backdrop
          sx={{ color: 'rgb(183,236,252)', zIndex: (theme) => theme.zIndex.drawer + 1 }}
          open
         
        >
          <CircularProgress color="inherit" />
        </Backdrop>) : ( <div className="ProductBox">
       
           
         



       {products.map((e) => {
       return <ProductComponent product={e} key={e.id} />;
       })}

      {/* <sortedList/> */}
    </div>)  }

      {/* <div className="ProductBox">
       
           
         



         {products.map((e) => {
         return <ProductComponent product={e} key={e.id} />;
         })}

       
      </div> */}
    </>
  );
};

export default ProductPage;
