import React from 'react'

const SuccessPage = () => {
  return (
    <div>
      success page
    </div>
  )
}

export default SuccessPage
