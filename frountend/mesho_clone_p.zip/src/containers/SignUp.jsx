import axios from "axios";
import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import './SignUp.css'

const SignUp = () => {
  const navigate = useNavigate();
  
  const [formdata, setFormdata] = useState("");

  const handleChange = (e) => {
    const { name, value } = e.target;
    //console.log(name, value);
    setFormdata({ ...formdata, [name]: value });
  };
  
  const handlesubmit = async (e) => {
    e.preventDefault();
    console.log("data", formdata);
    await axios.post("https://cloneuser.herokuapp.com/register", formdata);
    alert("registration successfully");
    navigate("/login");
  };

  return (
    <>
     <div className='mainBox'>
          <div className='subBox'>
              <h1>New Account</h1>
              <form onSubmit={handlesubmit}  className='form'>
                <input type="text" placeholder='Full Name'  
            name="name"
            onChange={handleChange}/>
                <input type="email" placeholder='Email' 
            name="email"
            onChange={handleChange}/>
                <input type="password" placeholder='Password'  
            name="password" 
            onChange={handleChange}/>
                <input className="btn" type="submit" value="Signup" />
              </form>
          </div>
     </div> 
    </>
  )
}

export default SignUp
 