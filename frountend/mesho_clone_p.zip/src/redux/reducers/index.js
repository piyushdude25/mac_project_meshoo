import {combineReducers} from 'redux'
import { productReducer, selectedProductReducer} from './productsReducer'
import { cartReducer } from "../../CartRedux/cartReducer";

// import {incdirReDucer} from './productsReducer'

 const reducers = combineReducers({
    allProducts: productReducer,
    product: selectedProductReducer,
    cartReducer:cartReducer,
    // incdirReDucer:incdirReDucer,

})
export default reducers